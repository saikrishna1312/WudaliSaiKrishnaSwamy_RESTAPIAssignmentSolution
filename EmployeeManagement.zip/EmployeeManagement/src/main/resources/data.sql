insert into employee values (1, 'Sai','Krishna', 'sk@gl.com');
insert into employee values (2, 'Prasanna','Narasimham', 'pn@gl.com');
insert into employee values (3, 'Sumanth','Koushik', 'suko@gl.com');
insert into employee values (4, 'Harshith','V', 'hv@gl.com');
insert into employee values (5, 'Aniketh','Reddy', 'ar@gl.com');